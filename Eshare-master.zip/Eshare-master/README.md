You can share what you want an article,memories etc.


After opening the site you will see this page
![image](https://github.com/maditya01/Eshare/assets/60269271/5cb942e0-644f-48a8-b6d2-3d248d79aa0c)

Next Sign up page if you are comming first time
![image](https://github.com/maditya01/Eshare/assets/60269271/a8827da0-3105-49d0-8a2c-01234f3a6c23)

Sign in page if you have already sign up
![image](https://github.com/maditya01/Eshare/assets/60269271/9a323ea7-606d-411e-b3dd-6439df271fe8)

Here you can create a post of your memories you can like other memories you can delete your memories you can comment on any post
![image](https://github.com/maditya01/Eshare/assets/60269271/77fc7b58-25a9-4f80-b645-da2c81129721)


![image](https://github.com/maditya01/Eshare/assets/60269271/e364052a-1537-4166-b723-560c4ae9c202)


You can click on any specific post
![image](https://github.com/maditya01/Eshare/assets/60269271/285fa709-8a5c-4d57-ae65-394ef1d049fc)



