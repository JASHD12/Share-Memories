import React from 'react'

const ArticleDetails = () => {
 return <div></div>
}

export default ArticleDetails
