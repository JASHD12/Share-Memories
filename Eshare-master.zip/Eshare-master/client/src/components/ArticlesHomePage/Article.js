import React from 'react'
import NavBar from '../NavBar/NavBar'
const Article = () => {
 return (
  <>
   <NavBar text="ARTICLES" />
   <div>IN Article Page</div>
   <form action="">
    <div>Post title</div>
    <div>Post Content</div>
    <div>Post tag</div>
   </form>
  </>
 )
}

export default Article
