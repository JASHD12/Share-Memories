import React from 'react'

const ArticleIndex = () => {
 return <div></div>
}

export default ArticleIndex
