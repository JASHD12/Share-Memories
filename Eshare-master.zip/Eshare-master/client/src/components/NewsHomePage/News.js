import React from 'react'

//This is Default export import karte samay {}
const News = () => {
 return <div>In news Section</div>
}
export default News
