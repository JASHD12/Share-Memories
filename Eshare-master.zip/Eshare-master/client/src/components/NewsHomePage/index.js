import React from 'react'

const NewsIndex = () => {
 return <div></div>
}

export default NewsIndex
