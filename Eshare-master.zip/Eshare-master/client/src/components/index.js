
// import React from 'react'
// import {Grid} from '@material-ui/core'
// import Card from '@material-ui/core/Card'
// import CardActions from '@material-ui/core/CardActions'
// import CardContent from '@material-ui/core/CardContent'
// import CardMedia from '@material-ui/core/CardMedia'
// import Button from '@material-ui/core/Button'
// import Typography from '@material-ui/core/Typography'
// import {Link} from 'react-router-dom'
// import memories from '../../images/memories.png'

// const Index = () => {
//  return (
//   <Grid container>
//    <Grid item>
//     <Card sx={{maxWidth: 45}}>
//      <CardMedia component="img" height="60" image={memories} alt="green iguana" />
//      <CardContent>
//       <Typography gutterBottom variant="h5">
//        Lizard
//       </Typography>
//       <Typography variant="body2" color="text.secondary">
//        Lizards are a widespread group of squamate reptiles, with over 6,000 species, ranging across all continents except Antarctica
//       </Typography>
//      </CardContent>
//      <CardActions>
//       <Button component={Link} to="/memories" size="small">
//        Post Some Memories
//       </Button>
//      </CardActions>
//     </Card>
//    </Grid>
//    <Grid item>
//     <Card sx={{maxWidth: 45}}>
//      <CardMedia component="img" height="60" image={memories} alt="green iguana" />
//      <CardContent>
//       <Typography gutterBottom variant="h5">
//        Lizard
//       </Typography>
//       <Typography variant="body2" color="text.secondary">
//        Lizards are a widespread group of squamate reptiles, with over 6,000 species, ranging across all continents except Antarctica
//       </Typography>
//      </CardContent>
//      <CardActions>
//       <Button component={Link} to="/articles" size="small">
//        Post Some Articles
//       </Button>
//      </CardActions>
//     </Card>
//    </Grid>
//    <Grid item>
//     <Card sx={{maxWidth: 45}}>
//      <CardMedia component="img" height="60" image={memories} alt="green iguana" />
//      <CardContent>
//       <Typography gutterBottom variant="h5">
//        Lizard
//       </Typography>
//       <Typography variant="body2" color="text.secondary">
//        Lizards are a widespread group of squamate reptiles, with over 6,000 species, ranging across all continents except Antarctica
//       </Typography>
//      </CardContent>
//      <CardActions>
//       <Button component={Link} to="/news" size="small">
//        Post Some News
//       </Button>
//      </CardActions>
//     </Card>
//    </Grid>
//   </Grid>
//  )
// }
// export default Index
